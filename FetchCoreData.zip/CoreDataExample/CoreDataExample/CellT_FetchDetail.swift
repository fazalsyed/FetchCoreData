//
//  CellT_FetchDetail.swift
//  CoreDataExample
//
//  Created by syed fazal abbas on 14/05/23.
//

import UIKit

class CellT_FetchDetail: UITableViewCell {

    @IBOutlet var View: UIView!
    @IBOutlet var lblName: UILabel!
    @IBOutlet var lblFather: UILabel!
    @IBOutlet var lblAddress: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
