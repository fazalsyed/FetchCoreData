//
//  Student+CoreDataClass.swift
//  CoreDataExample
//
//  Created by syed fazal abbas on 12/05/23.
//
//

import Foundation
import CoreData

@objc(Student)
public class Student: NSManagedObject {

}
