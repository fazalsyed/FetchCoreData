//
//  DataBaseHelper.swift
//  CoreDataExample
//
//  Created by syed fazal abbas on 12/05/23.
//

import Foundation
import UIKit
import CoreData

class DataBaseHelper{
    
    static let shareInstance = DataBaseHelper()
    let context = (UIApplication.shared.delegate as? AppDelegate)?.persistentContainer.viewContext
    
    func Savedata(collegeDict : [String:String]){
        let data = NSEntityDescription.insertNewObject(forEntityName: "Student", into: context!) as? Student
        data!.studentaddress = collegeDict["Address"]
        data!.studentfather = collegeDict["Father"]
        data!.studentname = collegeDict["Name"]
        do{
            try context?.save()
        }
        catch{
            print("Not Found")
        }
    }
    func fetchData() -> [Student]{
        var student = [Student]()
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Student")
        do {
            student = try (context?.fetch(fetchRequest) as! [Student])
        }
        catch{
            print("Not Found")
        }
        return student
    }
}
