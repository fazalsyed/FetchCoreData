//
//  FetchStudentData.swift
//  CoreDataExample
//
//  Created by syed fazal abbas on 14/05/23.
//

import UIKit

class FetchStudentData: UIViewController {

    @IBOutlet var tableView: UITableView!
    var student = [Student]()
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.dataSource = self
        tableView.delegate = self
        tableView.register(UINib(nibName: "CellT_FetchDetail", bundle: nil), forCellReuseIdentifier: "CellT_FetchDetail")
          student = DataBaseHelper.shareInstance.fetchData()
    }
}
extension FetchStudentData : UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return student.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CellT_FetchDetail") as? CellT_FetchDetail
        cell?.lblAddress.text = student[indexPath.row].studentaddress
        cell?.lblFather.text = student[indexPath.row].studentfather
        cell?.lblName.text = student[indexPath.row].studentname
        cell?.View.layer.cornerRadius = 10
        cell?.View.layer.masksToBounds = true
        cell?.View.clipsToBounds = false
        cell?.View.layer.borderColor = UIColor.black.cgColor
        cell?.View.layer.borderWidth = 1
        return cell!
    }
}
